package cibertec.pe.serviceimpl;

import java.io.File;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cibertec.pe.dto.FacturaDTO;
import cibertec.pe.entity.EnvioSunat;
import cibertec.pe.feign.FacturaFeignClient;
import cibertec.pe.repository.IEnvioSunatRepository;
import cibertec.pe.service.IEnvioSunatService;
import cibertec.pe.soap.SunatSoapClient;
import cibertec.pe.xml.XmlFacturaGenerator; // Sincronizado al componente dinámico correcto
import cibertec.pe.zip.ZipGenerator;

@Service
public class EnvioSunatImplement implements IEnvioSunatService {
        
    @Autowired
    private FacturaFeignClient facturaFeign;
    
    @Autowired
    private XmlFacturaGenerator xmlGenerator; // Inyección de la clase correcta
    
    @Autowired
    private IEnvioSunatRepository repository;
    
    @Autowired
    private ZipGenerator zipGenerator;
    
    @Autowired
    private SunatSoapClient soapClient;

    @Override public List<EnvioSunat> listar() { return repository.findAll(); }
    @Override public EnvioSunat guardar(EnvioSunat envio) { envio.setFechaEnvio(LocalDateTime.now()); if(envio.getEstado()==null) envio.setEstado("PENDIENTE"); return repository.save(envio); }
    @Override public Optional<EnvioSunat> buscar(Integer id) { return repository.findById(id); }
    @Override public void eliminar(Integer id) { repository.deleteById(id); }
    @Override public EnvioSunat actualizar(Integer id, EnvioSunat envio) { EnvioSunat r = repository.findById(id).orElse(null); if(r!=null){ r.setEstado(envio.getEstado()); r.setCodigoRespuesta(envio.getCodigoRespuesta()); r.setDescripcionRespuesta(envio.getDescripcionRespuesta()); return repository.save(r); } return null; }

    @Override
    public void generarXmlFactura(Integer idFactura) throws Exception {
        
        EnvioSunat envio = new EnvioSunat();
        envio.setIdFactura(idFactura);
        envio.setEstado("PROCESANDO");
        envio.setFechaEnvio(LocalDateTime.now());
        envio = repository.save(envio);

        try {
            // Consumo síncrono mediante el cliente Feign corregido
            FacturaDTO factura = facturaFeign.obtenerDatosParaSunat(idFactura);
            if (factura == null) {
                throw new RuntimeException("No se encontró el comprobante en el microservicio externo con ID: " + idFactura);
            }

            String tipoDocSunat = "FACTURA".equalsIgnoreCase(factura.getTipoComprobante()) ? "01" : "03";
            envio.setTipoDocumento(tipoDocSunat);
            envio.setSerie(factura.getNroSerie());
            envio.setNumero(String.valueOf(factura.getCorrelativo()));

            // Invocación al método dinámico con sintaxis camelCase correcta
            File xml = xmlGenerator.generarXml(factura);
            File zip = zipGenerator.generarZip(xml);
            String respuestaSunat = soapClient.enviar(zip);

            if (respuestaSunat.contains("Error de SUNAT SOAP") || respuestaSunat.contains("soapenv:Envelope")) {
                envio.setEstado("RECHAZADO");
                envio.setCodigoRespuesta("500"); 
                envio.setDescripcionRespuesta(respuestaSunat);
            } else {
                envio.setEstado("ACEPTADO");
                envio.setCodigoRespuesta("0"); 
                envio.setDescripcionRespuesta(respuestaSunat);
            }

        } catch (Exception e) {
            envio.setEstado("ERROR_INTERNO");
            envio.setCodigoRespuesta("500");
            envio.setDescripcionRespuesta("Excepción en el flujo: " + e.getMessage());
            throw e; 
            
        } finally {
            repository.save(envio);
        }
    }
}