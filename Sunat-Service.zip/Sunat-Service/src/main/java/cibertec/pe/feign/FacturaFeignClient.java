package cibertec.pe.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import cibertec.pe.dto.FacturaDTO;

// Verifica el name de tu microservicio de facturación local
@FeignClient(name = "facturacion-service") 
public interface FacturaFeignClient {

    // Método para traer los datos listos desde Facturacion-Service usando el ID local
    @GetMapping("/api/comprobantes/datos-sunat/{idComprobante}")
    FacturaDTO obtenerDatosParaSunat(@PathVariable("idComprobante") int idComprobante);
}