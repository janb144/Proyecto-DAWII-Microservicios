package cibertec.pe.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import cibertec.pe.dto.FacturaDTO;
import cibertec.pe.entity.EnvioSunat;
import cibertec.pe.feign.FacturaFeignClient;
import cibertec.pe.service.IEnvioSunatService;
import cibertec.pe.service.SunatProcesoService;

@RestController
@RequestMapping("/api/sunat")
public class EnvioSunatController {
    
    @Autowired
    private IEnvioSunatService service;
    
    @Autowired
    private FacturaFeignClient facturaFeign;
    
    @Autowired
    private SunatProcesoService sunatProcesoService;

    @GetMapping("/listar") public List<EnvioSunat> listar(){ return service.listar(); }
    @PostMapping("/registrar") public EnvioSunat registrar(@RequestBody EnvioSunat envio){ return service.guardar(envio); }
    @GetMapping("/buscar/{id}") public Optional<EnvioSunat> buscar(@PathVariable Integer id){ return service.buscar(id); }
    @PutMapping("/actualizar/{id}") public EnvioSunat actualizar(@PathVariable Integer id, @RequestBody EnvioSunat envio){ return service.actualizar(id, envio); }
    @DeleteMapping("/eliminar/{id}") public void eliminar(@PathVariable Integer id){ service.eliminar(id); }

    @GetMapping("/factura/{codigo}")
    public FacturaDTO obtenerFactura(@PathVariable int codigo) {
        FacturaDTO factura = facturaFeign.obtenerDatosParaSunat(codigo);
        if (factura == null) {
            throw new RuntimeException("No encontrado");
        }
        return factura;
    }

    @PostMapping("/xml/{idFactura}")
    public ResponseEntity<String> generarXml(@PathVariable Integer idFactura) {
        try {
            // Mapeo directo y seguro utilizando la sintaxis unificada de Feign
            FacturaDTO factura = facturaFeign.obtenerDatosParaSunat(idFactura);
            if (factura == null) {
                throw new RuntimeException("No se encontró la factura con ID: " + idFactura);
            }
            
            String respuestaSunat = sunatProcesoService.procesar(factura);
            return ResponseEntity.ok("Proceso completado: " + respuestaSunat);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al procesar el envío: " + e.getMessage());
        }
    }
}